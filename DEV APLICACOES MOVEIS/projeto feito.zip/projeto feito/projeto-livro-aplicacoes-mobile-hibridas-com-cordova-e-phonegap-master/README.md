# projeto-livro-aplicacoes-mobile-hibridas-com-cordova-e-phonegap
Projeto do livro Aplicações mobile híbridas com Cordova e PhoneGap de Sérgio Lopes.
